#!/usr/bin/env python3
import hashlib,json,sys
from pathlib import Path
here=Path(__file__).resolve().parent
root=here.parents[2]
manifest=json.loads((here/'MANIFEST.json').read_text())
for row in manifest['files']:
    p=root/row['path']
    if not p.is_file():raise SystemExit('MISSING: '+row['path'])
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    if p.stat().st_size!=row['bytes'] or h.hexdigest()!=row['sha256']:
        raise SystemExit('MISMATCH: '+row['path'])
print('OK:',len(manifest['files']),'files verified')
